sudo apt-get install ufw

sudo reboot
