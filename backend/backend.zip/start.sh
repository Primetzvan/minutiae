./create.sh
./createMQTTBroker.sh
npm run start:dev