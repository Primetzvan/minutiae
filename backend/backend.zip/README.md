<p align="center">
  <img src="../images/logo.svg" width="320" alt="Minutiae Logo" />
</p>

# Minutiae Backend

## Starting and running the backend
If you just want to start the backend, you have to run [create.sh](create.sh)
and afterwards [start.sh](start.sh)

### Run the System
If you want to run the whole system, we recommend following the instructions on the
[official githubpages](https://sarahfeichtinger.github.io/minutiae-website/)