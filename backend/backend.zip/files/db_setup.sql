DROP USER 'root'@'localhost';
FLUSH privileges;
CREATE DATABASE mariadb;
COMMIT;
quit
