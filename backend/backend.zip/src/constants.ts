export const DATABASE_NAME = 'mariadb';
