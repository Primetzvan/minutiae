export const clusterName = 'minutiae';
