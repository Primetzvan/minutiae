import * as ip from 'ip';

export const IP = ip.address();
